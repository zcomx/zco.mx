=== zco.mx Book Reader ===
Contributors: jimk
Stable tag: 1.0
Tested up to: 4.7
Requires at least: 1.0

This plugin can be used to insert zco.mx book readers into wordpress pages.

== Description ==

Use this plugin to convert images or links so when clicked, they trigger the
zco.mx book reader to popup allowing users to read a book.

To use, install the plugin, then activate.

Then any links with class="zco_book_reader" will be set up as book readers.
Set the href of the link to the zco.mx url of the specific book you want read.

Examples:
    # A link
    <a href="https://zco.mx/Cartoonist/BookTitle/001" class="zco_book_reader">Read</a>

    # Clickable image
    <a href="https://zco.mx/Cartoonist/BookTitle/001" class="zco_book_reader">
        <img src="https://zco.mx/images/download/book_page.image.b224f4ba0b8dff48.757074696768742d3030312d30312e706e67.png?cache=1&size=web"/>
    </a>
