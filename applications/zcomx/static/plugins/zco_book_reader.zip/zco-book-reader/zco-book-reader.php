<?php
/**
 * @package Zco_Book_Reader
 * @version 1.6
 */
/*
Plugin Name: zco.mx Book Reader
Plugin URI: https://zco.mx/zcomx/static/plugins/zco_book_reader.zip
Description: This plugin can be used to insert zco.mx book readers into wordpress pages.
Author: Jim Karsten
Version: 1.1
Author URI: http://zco.mx
Text Domain: zco-book-reader
*/


function zco_book_reader_plugin_init() {
    file_put_contents('/tmp/php.txt', "FIXME zco_book_reader_plugin called: " . PHP_EOL , FILE_APPEND);
    wp_register_script( 'zco-book-reader-script', 'https://zco.mx/zcomx/static/js/zco_book_reader.js', array('jquery'));
    wp_enqueue_script( 'zco-book-reader-script' );
}
add_action( 'init', 'zco_book_reader_plugin_init' );

?>
